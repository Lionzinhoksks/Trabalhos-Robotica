#ifndef Funcoes_H
#define Funcoes_H

void Mostrarinfo() {
    
}

#endif